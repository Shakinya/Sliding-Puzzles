import java.io.File;
import java.util.Scanner;
import java.time.Duration;
import java.time.Instant;


public class main {
    private final static Scanner inputReader = new Scanner(System.in);

    // Instance of the parser class to handle input file parsing
    private static parser parsedInputFile;

    // Flag to indicate if loading input can be skipped
    private static boolean shouldSkipLoad;
    private static File inputFile;
    private static String inputFileName;

    public static void main(String[] args) throws Exception
    {
        System.out.println();
        System.out.println("||------ SLIDING PUZZLES ------|| ");
        System.out.println();

        while (true) {
            shouldSkipLoad = false;

            System.out.println("Press 1 : Load new input");
            System.out.println("Press 0 : Quit the application");

            System.out.print("\nSelect : ");
            String loopChoice = inputReader.nextLine();

            switch (loopChoice) {
                case "0":
                    System.exit(0);
                    break;
                case "1":
                    loadNewInput();
                    break;
                default:
                    System.out.println("Invalid choice!");
                    break;
            }
        }
    }

    // Method to calculate the shortest distance in the maze
    private static void calculateDistance(){
        Instant startTime = null;
        Instant endTime = null;
        Duration timeElapsed = null;
        while (true) {
            System.out.println("No of lines : " + parsedInputFile.getLines().size());
            System.out.println("\n");
            System.out.println("Press 1 : Print the path");
            System.out.println("Press 9 : Restart the application.");

            System.out.print("\nSelect : ");

            String loopChoice = inputReader.nextLine();

            int[][] n = parsedInputFile.getPuzzle();
            int[] s = parsedInputFile.getStartPoint();
            int[] t = parsedInputFile.getEndPoint();

            algo_choosed solver = new algo_choosed();

            switch (loopChoice) {
                case "1":
                    if (startTime == null) {
                        startTime = Instant.now();
                    }
                    System.out.println("\nFinding the shortest distance..\n");

                    System.out.println(solver.shortestDistance(n, s, t));

                    if (endTime == null) {
                        endTime = Instant.now();
                        timeElapsed = Duration.between(startTime, endTime);
                    }
                    System.out.print("\nTime elapsed : ");

                    if (timeElapsed.toMillis() > 1000){
                        System.out.print(timeElapsed.toSeconds() + " seconds\n");
                        return;
                    }

                    System.out.print(timeElapsed.toMillis() + " milliseconds\n");
                    break;
                case "9":
                    System.out.println("\n");
                    inputFileName = null;
                    parsedInputFile = null;
                    shouldSkipLoad = true;
                    return;
                default:
                    System.out.println("Invalid choice!\n");
                    break;
            }
        }

    }

    // Method to load a new input file
    private static void loadNewInput()
    {
        while(true)
        {
            if (shouldSkipLoad)
                return;

            System.out.println("Press 1 : Select graph using file explorer");
            System.out.println("Press 2 : Enter graph name to select ( NOTE: Place it in the 'file-input' folder! ) ");
            System.out.println("Press 3 : Go back to main menu");

            System.out.print("\nSelect : ");
            String loopChoice = inputReader.nextLine();
            boolean graphLoadError = false;

            switch (loopChoice)
            {
                case "1":
                    System.out.println("Choose the text input file");
                    System.out.println("Please check the taskbar for a new icon");
                    try {
                        parser fileParser = new parser();
                        fileParser.readFile();
                        fileParser.loadLines();
                        fileParser.loadValues();
                        if (!fileParser.isFileRead()) {
                            throw new Exception("File not loaded!");
                        }
                        inputFileName = fileParser.getFileName();
                        inputFile = fileParser.getFile();
                        parsedInputFile = fileParser;
                    } catch (Exception e) {
                        System.out.println(e);
                        System.out.println("\nError reading input file, Please try again! \n");
                        graphLoadError = true;
                    }
                    if (!graphLoadError) {
                        shouldSkipLoad = true;
                        calculateDistance();
                    } else {
                        continue;
                    }
                    break;
                case "2":
                    System.out.println("Place the input text file in 'inputs' folder & In the console enter the text file name");
                    try {
                        String userInputFileName;
                        do {
                            System.out.println("Note : It should be a text file with the '.txt' file extension");
                            System.out.print("Input file name:  ");
                            userInputFileName = inputReader.nextLine();
                        } while ((!userInputFileName.endsWith(".txt")));

                        parser fileParser = new parser();
                        fileParser.readFile("src/inputs/" + userInputFileName);
                        fileParser.loadLines();
                        fileParser.loadValues();
                        if (!fileParser.isFileRead()) {
                            throw new Exception("File not loaded!");
                        }
                        inputFileName = fileParser.getFileName();
                        inputFile = fileParser.getFile();
                        parsedInputFile = fileParser;
                    } catch (Exception e) {
                        System.out.println(e);
                        System.out.println("\nError reading input file, Please try again!\n");
                        graphLoadError = true;
                    }

                    if (!graphLoadError) {
                        shouldSkipLoad = true;
                        calculateDistance();
                    } else {
                        continue;
                    }
                    break;
                case "3":
                    return;
                default:
                    System.out.println("Invalid choice!");
                    break;
            }
        }
    }
}

